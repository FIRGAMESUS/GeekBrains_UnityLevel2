﻿public interface ISetDamage
{
    void SetDamage(int damage);
}
